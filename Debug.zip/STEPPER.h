#ifndef STEPPER_H_
#define STEPPER_H_

void Stepper_Init(void);
void Stepper_Open_90deg(void);
void Stepper_Close_door(void);




#endif